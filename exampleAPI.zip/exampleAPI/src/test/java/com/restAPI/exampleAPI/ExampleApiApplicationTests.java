package com.restAPI.exampleAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
